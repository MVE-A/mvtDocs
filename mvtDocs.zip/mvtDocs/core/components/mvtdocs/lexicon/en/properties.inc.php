<?php
$_lang['modextra_prop_resource'] = 'Resource';
$_lang['mvtdocs_prop_limit'] = 'The number of Items to limit per page.';
$_lang['mvtdocs_prop_where'] = 'JSON encoded string with additional fetch conditions';
$_lang['mvtdocs_prop_sortBy'] = 'The field to sort by';
$_lang['mvtdocs_prop_sortDir'] = 'The direction to sort by';
$_lang['mvtdocs_prop_tpl'] = 'The chunk to use for each row of Items';
$_lang['modextra_prop_outputSeparator'] = 'Line output delimiter';
$_lang['mvtdocs_prop_toPlaceholder'] = 'If set, will output the content to the placeholder specified in this property, rather than outputting the content directly';
