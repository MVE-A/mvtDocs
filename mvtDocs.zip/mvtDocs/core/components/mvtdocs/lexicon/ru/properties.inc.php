<?php
$_lang['modextra_prop_resource'] = 'Ресурс. По умолчанию - текущий';
$_lang['modextra_prop_limit'] = 'Ограничение вывода Предметов на странице';
$_lang['modextra_prop_outputSeparator'] = 'Разделитель вывода строк';
$_lang['mvtdocs_prop_sortBy'] = 'Поле сортировки';
$_lang['mvtdocs_prop_sortDir'] = 'Направление сортировки';
$_lang['mvtdocs_prop_tpl'] = 'Чанк оформления одной записи';
$_lang['mvtdocs_prop_where'] = 'Строка, закодированная в JSON, с дополнительными условиями выборки';
$_lang['mvtdocs_prop_toPlaceholder'] = 'Усли указан этот параметр, то результат будет сохранен в плейсхолдер, вместо прямого вывода на странице';
