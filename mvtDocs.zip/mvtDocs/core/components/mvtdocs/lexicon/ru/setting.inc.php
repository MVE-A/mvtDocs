<?php

$_lang['area_mvtdocs_main'] = 'Основные';

$_lang['setting_mvtdocs_document_types'] = 'Типы документов';
$_lang['setting_mvtdocs_document_types_desc'] = 'Список типов документов, через «,»';
$_lang['setting_mvtdocs_source'] = 'Источник файлов';
$_lang['setting_mvtdocs_source_desc'] = 'Укажите источник файлов для загрузки документов';
$_lang['setting_mvtdocs_filename_translit'] = 'Транслитерировать имена файлов';
$_lang['setting_mvtdocs_filename_translit_desc'] = 'Если «Да», имена файлов будут транслитерированы в соответствии с настройками дружественных урлов';

$_lang['setting_mvtdocs_category'] = 'Ограничить разделом';
$_lang['setting_mvtdocs_category_desc'] = 'Укажите ID раздела, которым вы хотите ограничить работу с документами';
$_lang['setting_mvtdocs_auto_links'] = 'Создавать связи автоматически';
$_lang['setting_mvtdocs_auto_links_desc'] = 'Если установлен minishop2, то вы можете указать «да» для автоматического выставления связей файлов на все товары, связанные с данным';
$_lang['setting_mvtdocs_links_ids'] = 'Использовать только указанные связи';
$_lang['setting_mvtdocs_links_ids_desc'] = 'Если «Создавать связи автоматически» = «Да», то вы можете указать через «,» список идентификаторов связей товаров для которых
 разрешается формировать автоматические связи для файлов. Необходимо, если у вас несколько типов связей и вы не хотите задействовать все.';