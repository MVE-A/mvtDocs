<?php
class mvtDocsFiles extends xPDOSimpleObject {}