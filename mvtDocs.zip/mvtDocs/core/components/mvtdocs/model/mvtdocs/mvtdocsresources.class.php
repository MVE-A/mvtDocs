<?php
class mvtDocsResources extends xPDOSimpleObject {}