<?php
require_once (dirname(__DIR__) . '/mvtdocsfiles.class.php');
class mvtDocsFiles_mysql extends mvtDocsFiles {}