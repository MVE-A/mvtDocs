<?php
require_once (dirname(__DIR__) . '/mvtdocsresources.class.php');
class mvtDocsResources_mysql extends mvtDocsResources {}