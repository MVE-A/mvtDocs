<?php

$xpdo_meta_map = array (
  'xPDOSimpleObject' => 
  array (
    0 => 'mvtDocsFiles',
    1 => 'mvtDocsResources',
  ),
);